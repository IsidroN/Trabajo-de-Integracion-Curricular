/* ********************************************************************************************************************************
ESCUELA POLIT�CNICA NACIONAL
FACULTAD DE INGENIER�A EL�CTRICA Y ELECTR�NICA
 													
AUTOR:	 ISIDRO MOISES NAVARRETE MENDEZ												
TEMA:  	 IMPLEMENTACI�N DE UN ALGORITMO PARA LA ELIMINACI�N 
         DE TRAMAS REPETIDAS EN AMBIENTES CON TOPOLOG�A
         LINEAL QUE OPERAN CON EL PROTOCOLO IEEE 802.15.4. 
***********************************************************************************************************************************/
// ****************************************************** NODO ***************************************************** //
#include "stdio.h"
#include "string.h"
#include "usr_wireless.h"
#include "wireless_config.h"

int transmit=0;
char RupturaOrigen[16]="Ruptura S 0x000n";
char sensado ='F';
void usr_wireless_app_task(void)
{
if (transmit == 1){
	transmit_sample_frame((uint8_t*)RupturaOrigen, 16);

	}else if (transmit == 2){
		trama_recibida.payload[8]='F';
		transmit_sample_frame(trama_recibida.payload,16);
		
		}else if (transmit == 3){
		transmit_sample_frame(trama_recibida.payload,16);
		
	}
     transmit=0;
}

// Funcion de recepcion //
void usr_frame_received_cb(frame_info_t *frame)
{
	memset(&trama_recibida,0,sizeof(trama_recibida));// Reserva el espacio de memoria
	memcpy(&trama_recibida,frame->mpdu,sizeof(trama_recibida));// Copia la informacion de la memoria fuente(buffer) al detino
	bmm_buffer_free(frame->buffer_header);//Elimina los datos del buffer, evita superpocicion.
	
	uint16_t dirOrigen;//Direccion del mensaje Recibido
	//uint8_t msgTypeMQTT_SN;//Tipo de mensaje
	//uint8_t longitudMQTT_SN;//Longitud del mensaje 
	
	dirOrigen=trama_recibida.d_orgn;
	//longitudMQTT_SN= trama_recibida.payload[0];
	//msgTypeMQTT_SN= trama_recibida.payload[1];

if (dirOrigen==0x1000 && strncmp((const char *) trama_recibida.payload, "Ruptura", 7) == 0){ // Recibe la direccion origen del nodo
	//  &&  Mediante la variable msgTypeMQTT_SN se procede a comprobar el tipo de mensaje recido.

	RupturaOrigen [8] = 'T'; // variable que determina si este nodo recibio la alerta
	RupturaOrigen [15] =  SRC_ADDR + '0'; //agrega su direccion al mensaje
	//delay_ms(tiempo*SRC_ADDR);
	transmit=1;
	//transmit_sample_frame((uint8_t*)RupturaOrigen, 16);	//transmite el mensaje
	sensado ='T';	//variable que determina si este nodo senso
	//bmm_buffer_free(frame->buffer_header);//Elimina los datos del buffer, evita superpocicion.

	//en el caso de que reciba mensaje de ruptura de un nodo a su alcance, se realiza las siguientes comprobaciones:
	
	//1.-si llega de un nodo que ya senso, no he sensado y es el anterior nodo, transmito
	
	}else if(strncmp((const char *) trama_recibida.payload, "Ruptura T", 9)==0  && sensado =='F' && dirOrigen == SRC_ADDR - 1){
	
	//trama_recibida.payload[8]='F'; //Modifico el mesnaje para decir que no he sensado
	// delay_ms(tiempo*SRC_ADDR);
	transmit=2;
	//transmit_sample_frame(trama_recibida.payload,16);
	// bmm_buffer_free(frame->buffer_header);
	
	}else if(strncmp((const char *) trama_recibida.payload, "Ruptura F", 9)==0 && sensado =='F'  &&  dirOrigen == SRC_ADDR - 2){
	//si llega de un nodo que no senso, no he transmitido, y es el nodo anterior anterior, transmito y transmitir es TRUE
	//		 delay_ms(tiempo*SRC_ADDR);
	transmit=3;
	//transmit_sample_frame(trama_recibida.payload,16);
	//		 bmm_buffer_free(frame->buffer_header);

	}else if (dirOrigen==0x1000 && strncmp((const char *) trama_recibida.payload, "Fin Ruptura", 11) == 0){

	sensado ='F';
	//bmm_buffer_free(frame->buffer_header);
	
}

}


void usr_frame_transmitted_cb(retval_t status, frame_info_t *frame)
{

}

/*	
if (dirOrigen==0x1001 && strncmp((const char *) trama_recibida.payload, "Ruptura", 7) == 0){ // Recibe la direccion origen del nodo
	//  &&  Mediante la variable msgTypeMQTT_SN se procede a comprobar el tipo de mensaje recido.

	RupturaOrigen [8] = 'T'; // variable que determina si este nodo recibio la alerta
	RupturaOrigen [15] =  SRC_ADDR + '0'; //agrega su direccion al mensaje
	//delay_ms(tiempo*SRC_ADDR);
	transmit_sample_frame((uint8_t*)RupturaOrigen, 16);	//transmite el mensaje
	sensado ='T';	//variable que determina si este nodo senso
	bmm_buffer_free(frame->buffer_header);//Elimina los datos del buffer, evita superpocicion.

	//en el caso de que reciba mensaje de ruptura de un nodo a su alcance, se realiza las siguientes comprobaciones:
	
	//1.-si llega de un nodo que ya senso, no he sensado y es el anterior nodo, transmito
	
	}else if(strncmp((const char *) trama_recibida.payload, "Ruptura", 7)==0 &&  dirOrigen == SRC_ADDR - 1){
	
	transmit_sample_frame(trama_recibida.payload,16);

	
	}else if(strncmp((const char *) trama_recibida.payload, "Ruptura", 7)==0  && dirOrigen == SRC_ADDR - 2){
	//si llega de un nodo que no senso, no he transmitido, y es el nodo anterior anterior, transmito y transmitir es TRUE

	transmit_sample_frame(trama_recibida.payload,16);

	}else if (dirOrigen==0x1000 && strncmp((const char *) trama_recibida.payload, "Fin Ruptura", 11) == 0){

	sensado ='F';
	bmm_buffer_free(frame->buffer_header);
	
}

}*/













/* 	

void usr_frame_transmitted_cb(retval_t status, frame_info_t *frame)
{

}
//#include "dato.h"
//datos misdatos;
							//uint8_t c[4];
							// c[0]='Fin Ruptura';
							//transmit_sample_frame(c,10);
								//(dirOrigen == SRC_ADDR - 1 || dirOrigen == SRC_ADDR - 2) &&
								//dir = dirOrigen + 1; //tal_pib_set(macShortAddress, (pib_value_t *)&dir); //transmit_sample_frame(trama_recibida.payload,7); //		 delay_ms(tiempo*SRC_ADDR)
									//	start_timer1();
									
											
			/*	if (TimerFinaliza == 1)
				{
					TimerFinaliza = 0;
					//contador2 = contador2 + 1;
					start_timer1();
				}*/